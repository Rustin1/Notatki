def wypelnij_liste(lista):
    i = 0
    while i < 10:
        lista.append(0)
        i=i+1


lista = []
wypelnij_liste(lista)
print(lista)
