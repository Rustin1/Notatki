def z1(lista):
    a = lista[0]
    b = lista[len(lista)-1]
    lista[0] = b
    lista[len(lista)-1] = a


def z2(lista):
    a = lista[len(lista)-1]
    for i in range(-1,-len(lista),-1):
        lista[i] = lista[i-1]
    lista[0] = a


def z3(lista):
    for i in range(len(lista)):
        if lista[i]%2 == 0:
            lista[i] = 0


def z4(lista):
    for i in range(1,len(lista)-1,2):
        if lista[i] > lista[i+1]:
            lista[i+1] = lista[i]
        else:
            lista[i] = lista[i + 1]


if __name__ == "__main__":
    lista = [1,2,3,4,5,6,7,8,9,10]
    z4(lista)
    print(lista)
