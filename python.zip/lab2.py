from typing import Any


class Node:
    data: Any = None
    next: 'Node' = None


class LinkedList:
    head: Node = None
    tail: Node = None

    def push(self, value: Any):
        if not self.head:
            self.head = Node()
            self.head.data = value
            self.tail = self.head
        else:
            temp = self.head
            self.head = Node()
            self.head.data = value
            self.head.next = temp
        return self.head

    def append(self, value: Any):
        if not self.head:
            self.head = Node()
            self.head.data = value
            self.tail = self.head
        else:
            self.tail.next = Node()
            self.tail = self.tail.next
            self.tail.data = value
        return self.tail

    def node(self, at: int):
        picked = self.head
        at = at
        while at > 0:
            if not picked.next:
                picked = self.head
            else:
                picked = picked.next
            at = at - 1
        return picked

    def insert(self, value: Any, after: Node):
        picked = self.head
        while picked:
            if picked == after:
                temp = picked.next
                picked.next = Node()
                picked.next.data = value
                picked.next.next = temp
                return picked.next
            else:
                picked = picked.next
        return False

    def pop(self):
        temp = self.head
        if temp:
            self.head = self.head.next
            return temp
        return False

    def remove_last(self):
        temp = self.tail
        picked = self.head
        if self.head == self.tail:
            self.head = None
            self.tail = None
            return temp
        while not picked.next == self.tail:
            picked = picked.next
        self.tail = picked
        return temp

    def remove(self, after: Node):
        picked = self.head
        while picked:
            if picked == after:
                temp = picked.next
                if picked.next == self.tail:
                    self.tail = picked
                picked.next = picked.next.next
                return temp
            else:
                picked = picked.next
        return False

    def __str__(self):
        str_list: str
        picked = self.head
        if picked:
            str_list = str(picked.data)
            while not picked == self.tail:
                picked = picked.next
                str_list = str_list + " -> " + str(picked.data)
            return str_list
        return ""

    def __len__(self):
        i = 1
        picked = self.head
        if picked:
            while not picked == self.tail:
                picked = picked.next
                i = i + 1
            return i
        return 0


list_ = LinkedList()

assert list_.head == None

list_.push(1)
list_.push(0)

assert str(list_) == '0 -> 1'

list_.append(9)
list_.append(10)

assert str(list_) == '0 -> 1 -> 9 -> 10'

middle_node = list_.node(1)
list_.insert(5, middle_node)

assert str(list_) == '0 -> 1 -> 5 -> 9 -> 10'


first_element = list_.node(0)
returned_first_element = list_.pop()

assert first_element == returned_first_element

last_element = list_.node(3)
returned_last_element = list_.remove_last()

assert last_element == returned_last_element
assert str(list_) == '1 -> 5 -> 9'

second_node = list_.node(1)
list_.remove(second_node)

assert str(list_) == '1 -> 5'
