def wypisz_imie(literka, Nazwisko):
    return literka[0].upper()+". "+Nazwisko[0].upper()+Nazwisko[1:].lower()


def aktywuj_funkcje(arg1, arg2, funkcja):
    return funkcja(arg1, arg2)


print(aktywuj_funkcje("jan", "kowalski", wypisz_imie))
