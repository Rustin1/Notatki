def wypelnij_liste(lista):
    for i in range(10):
        lista.append((i+1)*(i+1))


lista = []
wypelnij_liste(lista)
print(lista)
