def policz_wiek(stulecie, rok, wiek):
    return stulecie*100+rok-wiek


print(policz_wiek(20, 22, 21))
