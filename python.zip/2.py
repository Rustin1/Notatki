def wypisz_imie(literka, Nazwisko):
    return literka[0].upper()+". "+Nazwisko[0].upper()+Nazwisko[1:].lower()


print(wypisz_imie("jaN", "kOwAlSkI"))
