def wypisz_imie(literka, Nazwisko):
    return literka+". "+Nazwisko


print(wypisz_imie("J", "Kowalski"))
