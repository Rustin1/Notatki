def podziel(arg1, arg2):
    if arg1 >= 0 & arg2 >= 0:
        return arg1/arg2
    return 0


print(podziel(2, 2))
